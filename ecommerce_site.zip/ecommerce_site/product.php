<?php
session_start();
require_once 'includes/functions.php';
$conn = getDBConnection();




if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$productId = (int)$_GET['id'];
$product = getProductById($conn, $productId);


if (!$product) {
    header('Location: index.php');
    exit;
}


if (isset($_POST['add_to_cart'])) {
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    addToCart($productId, $quantity);
    header('Location: product.php?id=' . $productId . '&added=true');
    exit;
}

include 'includes/header.php';
?>

<main class="container py-4">
    <?php if (isset($_GET['added'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Product added to cart! <a href="cart.php" class="alert-link">View Cart</a>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>


    <nav class="mb-4" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item">
                <a href="index.php?category=<?php echo htmlspecialchars($product['category_id']); ?>">
                    <?php echo htmlspecialchars($product['category_name'] ?? 'Category'); ?>
                </a>
            </li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($product['title']); ?></li>
        </ol>
    </nav>


    <div class="row">
 
        <div class="col-md-6 mb-4">
            <img src="assets/images/<?php echo !empty($product['image']) ? htmlspecialchars($product['image']) : 'placeholder.jpg'; ?>"
                 class="img-fluid rounded" alt="<?php echo htmlspecialchars($product['title']); ?>"
                 style="max-height: 400px; object-fit: cover;">
        </div>

        
        <div class="col-md-6">
            <h1><?php echo htmlspecialchars($product['title']); ?></h1>
            <p class="text-muted">Sold by <?php echo htmlspecialchars($product['seller_name']); ?></p>
            <h4 class="text-primary mb-4"><?php echo formatCurrency($product['price']); ?></h4>

            <form method="POST" action="product.php?id=<?php echo urlencode($productId); ?>">
                <div class="mb-3">
                    <label class="form-label">Quantity</label>
                    <div class="input-group" style="width: 150px;">
                        <button type="button" class="btn btn-outline-secondary decrease-qty">-</button>
                        <input type="number" name="quantity" id="quantity" value="1" min="1" class="form-control text-center">
                        <button type="button" class="btn btn-outline-secondary increase-qty">+</button>
                    </div>
                </div>

                <div class="d-flex gap-2 flex-wrap">
                    <button type="submit" name="add_to_cart" class="btn btn-primary">
                        <i class="fas fa-shopping-cart me-1"></i>Add to Cart
                    </button>
                    <?php if (isLoggedIn()): ?>
                        <a href="contact-seller.php?product=<?php echo urlencode($productId); ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-envelope me-1"></i>Contact Seller
                        </a>
                    <?php endif; ?>
                </div>
            </form>

            <div class="card mt-4">
                <div class="card-header">Description</div>
                <div class="card-body">
                    <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header">Seller Info</div>
                <div class="card-body">
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($product['seller_name']); ?></p>
                    <p><strong>Listed:</strong> <?php echo date('F Y', strtotime($product['created_at'])); ?></p>
                </div>
            </div>
        </div>
    </div>

    
    <hr class="my-5">
    <h3 class="mb-4">Related Products</h3>
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <?php
        $stmt = $conn->prepare("
            SELECT p.*, u.name as seller_name
            FROM products p
            JOIN users u ON p.seller_id = u.id
            WHERE p.category_id = ? AND p.id != ? AND p.status = 'active'
            ORDER BY RAND()
            LIMIT 4
        ");
        $stmt->execute([$product['category_id'], $productId]);
        $related = $stmt->fetchAll();

        foreach ($related as $rel): ?>
            <div class="col">
                <div class="card h-100">
                    <img src="assets/images/<?php echo !empty($rel['image']) ? htmlspecialchars($rel['image']) : 'placeholder.jpg'; ?>"
                         class="card-img-top" alt="<?php echo htmlspecialchars($rel['title']); ?>"
                         style="height: 200px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($rel['title']); ?></h5>
                        <p class="text-primary fw-bold"><?php echo formatCurrency($rel['price']); ?></p>
                    </div>
                    <div class="card-footer bg-white">
                        <a href="product.php?id=<?php echo urlencode($rel['id']); ?>" class="btn btn-outline-primary w-100 btn-sm">
                            View Details
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const qty = document.querySelector('#quantity');
    document.querySelector('.increase-qty').onclick = () => qty.value = parseInt(qty.value) + 1;
    document.querySelector('.decrease-qty').onclick = () => {
        if (parseInt(qty.value) > 1) qty.value = parseInt(qty.value) - 1;
    };
});
</script>

<?php include 'includes/footer.php'; ?>
