<?php include __DIR__ . '/includes/header.php'; ?>

<main class="d-flex align-items-center justify-content-center flex-grow-1 p-4">
  <div class="container" style="max-width: 400px;">
    <div class="text-center mb-4">
      <h1 class="fw-bold">Create an account</h1>
      <p class="text-muted">Sign up to start buying and selling</p>
    </div>
    <form id="registerForm">
      <div class="mb-3">
        <label for="name" class="form-label">Full Name</label>
        <input type="text" id="name" class="form-control" required />
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email Address</label>
        <input type="email" id="email" class="form-control" required />
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" id="password" class="form-control" required />
      </div>
      <button type="submit" class="btn btn-primary w-100">Register</button>
    </form>
    <div class="text-center mt-3">
      <p class="text-muted">
        Already have an account? <a href="login.php" class="text-decoration-underline">Sign in</a>
      </p>
    </div>
  </div>
</main>

<?php include __DIR__ . '/includes/footer.php'; ?>
