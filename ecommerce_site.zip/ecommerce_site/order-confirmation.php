<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$orderId = (int) $_GET['id'];

$stmt = $conn->prepare("
    SELECT o.*, u.name AS customer_name, u.email
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.id = ?
");
$stmt->bind_param("i", $orderId);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();
$stmt->close();

if (!$order) {
    die("Order not found.");
}

$stmtItems = $conn->prepare("
    SELECT oi.*, p.title
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmtItems->bind_param("i", $orderId);
$stmtItems->execute();
$resultItems = $stmtItems->get_result();
$items = $resultItems->fetch_all(MYSQLI_ASSOC);
$stmtItems->close();

include 'includes/header.php';
?>

<style>
    .confirmation-box {
        max-width: 700px;
        margin: 40px auto;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 0 15px rgba(0,0,0,0.1);
        padding: 30px;
        font-family: sans-serif;
    }
    .confirmation-box h2 {
        color: #28a745;
        margin-bottom: 10px;
    }
    .confirmation-box .summary {
        background: #f1f1f1;
        border-radius: 8px;
        padding: 20px;
        margin-top: 20px;
    }
    .summary-table {
        width: 100%;
    }
    .summary-table td {
        padding: 8px 0;
    }
</style>

<div class="confirmation-box">
    <h2>Thank You for Your Order!</h2>
    <p>Your order has been successfully placed.</p>
    
    <div class="summary mt-4">
        <h5>Order Confirmation No: <strong>#<?php echo $order['id']; ?></strong></h5>
        <table class="summary-table">
            <tr>
                <td><strong>Customer:</strong></td>
                <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
            </tr>
            <tr>
                <td><strong>Shipping:</strong></td>
                <td>
                    <?php echo htmlspecialchars($order['shipping_address']); ?><br>
                    <?php echo htmlspecialchars($order['shipping_city']); ?>, 
                    <?php echo htmlspecialchars($order['shipping_state']); ?> 
                    <?php echo htmlspecialchars($order['shipping_zip']); ?>
                </td>
            </tr>
            <tr>
                <td><strong>Status:</strong></td>
                <td><?php echo ucfirst($order['status']); ?></td>
            </tr>
            <tr>
                <td><strong>Order Date:</strong></td>
                <td><?php echo date("F j, Y", strtotime($order['created_at'])); ?></td>
            </tr>
        </table>

        <hr>

        <h6 class="mt-4">Items Ordered:</h6>
        <ul>
            <?php foreach ($items as $item): ?>
                <li><?php echo htmlspecialchars($item['title']); ?> x <?php echo $item['quantity']; ?> – <?php echo formatCurrency($item['price']); ?></li>
            <?php endforeach; ?>
        </ul>

        <hr>

        <table class="summary-table mt-3">
            <tr>
                <td><strong>Subtotal:</strong></td>
                <td><?php echo formatCurrency($order['total_amount'] - 10 - ($order['total_amount'] * 0.08)); ?></td>
            </tr>
            <tr>
                <td><strong>Shipping:</strong></td>
                <td><?php echo formatCurrency(10.00); ?></td>
            </tr>
            <tr>
                <td><strong>Tax (8%):</strong></td>
                <td><?php echo formatCurrency($order['total_amount'] * 0.08); ?></td>
            </tr>
            <tr>
                <td><strong>Total:</strong></td>
                <td><strong><?php echo formatCurrency($order['total_amount']); ?></strong></td>
            </tr>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
