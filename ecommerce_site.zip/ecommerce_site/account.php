<?php

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';


if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';


$userId = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$userId]);
$user = $stmt->fetch();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    
    
    if (empty($name) || empty($email)) {
        $error = 'Name and email are required.';
    } elseif ($email !== $user['email']) {
        
        $checkSql = "SELECT COUNT(*) FROM users WHERE email = ? AND id != ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->execute([$email, $userId]);
        
        if ($checkStmt->fetchColumn() > 0) {
            $error = 'Email already in use by another account.';
        }
    }
    
    
    if (!empty($currentPassword)) {
        if (!password_verify($currentPassword, $user['password'])) {
            $error = 'Current password is incorrect.';
        } elseif (empty($newPassword) || empty($confirmPassword)) {
            $error = 'New password and confirmation are required.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'New password and confirmation do not match.';
        } elseif (strlen($newPassword) < 6) {
            $error = 'New password must be at least 6 characters long.';
        }
    }
    
    
    if (empty($error)) {
        
        $updateFields = ['name = ?', 'email = ?'];
        $params = [$name, $email];
        
        
        if (!empty($newPassword)) {
            $updateFields[] = 'password = ?';
            $params[] = password_hash($newPassword, PASSWORD_DEFAULT);
        }
        
        
        $params[] = $userId;
        
        
        $updateSql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $updateStmt = $conn->prepare($updateSql);
        
        if ($updateStmt->execute($params)) {
            
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            
            $success = 'Your account has been updated successfully.';
            
            
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
        } else {
            $error = 'Failed to update account. Please try again.';
        }
    }
}


include 'includes/header.php';
?>

<main class="container py-4">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">My Account</li>
        </ol>
    </nav>
    
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Account Navigation</h5>
                </div>
                <div class="list-group list-group-flush">
                    <a href="account.php" class="list-group-item list-group-item-action active">Account Details</a>
                    <a href="orders.php" class="list-group-item list-group-item-action">My Orders</a>
                    <a href="sell.php" class="list-group-item list-group-item-action">Sell Products</a>
                    <a href="logout.php" class="list-group-item list-group-item-action text-danger">Logout</a>
                </div>
            </div>
        </div>
        
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Account Details</h5>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                        </div>
                    <?php endif; ?>
                    
                    <form method="POST" action="account.php" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                            <div class="invalid-feedback">
                                Please enter your name.
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            <div class="invalid-feedback">
                                Please enter a valid email address.
                            </div>
                        </div>
                        
                        <hr class="my-4">
                        <h6>Change Password</h6>
                        <p class="text-muted small mb-3">Leave fields blank to keep your current password.</p>
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password">
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password">
                            <div class="form-text">Password must be at least 6 characters long.</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Update Account</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<?php

include 'includes/footer.php';
?>