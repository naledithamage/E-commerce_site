<?php

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';


if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $productId = isset($_POST['product_id']) ? $_POST['product_id'] : '';
    
    if ($action === 'update' && !empty($productId)) {
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        updateCartItemQuantity($productId, $quantity);
    } elseif ($action === 'remove' && !empty($productId)) {
        removeFromCart($productId);
    } elseif ($action === 'clear') {
        $_SESSION['cart'] = [];
    }
    
    
    header('Location: cart.php');
    exit;
}


$cart = getCartItems($conn);


include 'includes/header.php';
?>

<main class="container py-4">
    <h1 class="mb-4">
        <i class="fas fa-shopping-cart me-2"></i>Your Cart
    </h1>
    
    <?php if (empty($cart['items'])): ?>
        <div class="alert alert-info">
            <p class="mb-2">Your cart is empty.</p>
            <a href="index.php" class="btn btn-primary">Continue Shopping</a>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0">Cart Items (<?php echo count($cart['items']); ?>)</h5>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="col">Product</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Subtotal</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart['items'] as $item): ?>
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <?php
                                                    $imageFile = !empty($item['image']) ? $item['image'] : 'placeholder.jpg';
                                                    $imagePath = 'assets/images/' . $imageFile;
                                                    ?>
                                                    <img src="<?php echo $imagePath; ?>"
                                                         alt="<?php echo htmlspecialchars($item['title']); ?>"
                                                         class="cart-item-img rounded me-3"
                                                         style="width: 60px; height: auto;"
                                                         onerror="this.onerror=null;this.src='assets/images/placeholder.jpg';">
                                                    <div>
                                                        <h6 class="mb-0"><?php echo htmlspecialchars($item['title']); ?></h6>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><?php echo formatCurrency($item['price']); ?></td>
                                            <td>
                                                <form method="POST" action="cart.php" class="quantity-control-form">
                                                    <input type="hidden" name="action" value="update">
                                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                    <div class="quantity-control" style="width: 120px;">
                                                        <div class="input-group">
                                                            <button class="btn btn-outline-secondary decrease-qty" type="button">-</button>
                                                            <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" class="form-control text-center quantity-input">
                                                            <button class="btn btn-outline-secondary increase-qty" type="button">+</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </td>
                                            <td><?php echo formatCurrency($item['subtotal']); ?></td>
                                            <td>
                                                <form method="POST" action="cart.php">
                                                    <input type="hidden" name="action" value="remove">
                                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm" onclick="return confirmDelete('Remove this item from cart?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="index.php" class="btn btn-outline-primary">
                                <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                            </a>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="action" value="clear">
                                <button type="submit" class="btn btn-outline-danger" onclick="return confirmDelete('Clear your entire cart?')">
                                    <i class="fas fa-trash me-2"></i>Clear Cart
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <div class="card cart-summary">
                    <div class="card-header">
                        <h5 class="mb-0">Order Summary</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal:</span>
                            <span><?php echo formatCurrency($cart['total']); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Shipping:</span>
                            <span><?php echo formatCurrency(10.00); ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Tax (8%):</span>
                            <span><?php echo formatCurrency($cart['total'] * 0.08); ?></span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <strong>Total:</strong>
                            <strong><?php echo formatCurrency($cart['total'] + 10.00 + ($cart['total'] * 0.08)); ?></strong>
                        </div>
                        <div class="d-grid">
                            <a href="<?php echo isLoggedIn() ? 'checkout.php' : 'login.php?redirect=checkout.php'; ?>" class="btn btn-primary">
                                Proceed to Checkout
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</main>

<?php

include 'includes/footer.php';
?>
