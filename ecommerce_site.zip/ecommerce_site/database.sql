
CREATE DATABASE IF NOT EXISTS ecommerce;
USE ecommerce;


CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL
);


CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL UNIQUE
);


CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT NOT NULL,
    seller_id INT NOT NULL,
    image VARCHAR(255),
    is_featured TINYINT(1) DEFAULT 0,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id),
    FOREIGN KEY (seller_id) REFERENCES users(id)
);


CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    shipping_address VARCHAR(255) NOT NULL,
    shipping_city VARCHAR(100) NOT NULL,
    shipping_state VARCHAR(100) NOT NULL,
    shipping_zip VARCHAR(20) NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'cancelled') NOT NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);


CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);


INSERT INTO categories (name) VALUES 
('Electronics'),
('Clothing'),
('Home & Garden'),
('Sports & Outdoors'),
('Toys & Games');


INSERT INTO users (name, email, password, created_at) VALUES 
('John Doe', 'john@example.com', '$2y$10$LrJkFEE9pDiSHXa6lPXld.HgoGgcYRuJYbGNXhHsAjHWFEepK3KFe', NOW()),
('Jane Smith', 'jane@example.com', '$2y$10$LrJkFEE9pDiSHXa6lPXld.HgoGgcYRuJYbGNXhHsAjHWFEepK3KFe', NOW());


INSERT INTO products (title, description, price, category_id, seller_id, image, is_featured, created_at) VALUES 
('Wireless Headphones', 'Premium noise-cancelling wireless headphones with 30-hour battery life.', 199.99, 1, 1, 'assets/images/placeholder.jpg', 1, NOW()),
('Denim Jacket', 'Classic denim jacket with a modern fit.', 59.99, 2, 2, 'assets/images/placeholder.jpg', 1, NOW()),
('Indoor Plant Set', 'Set of 3 easy-care indoor plants with decorative pots.', 34.99, 3, 1, 'assets/images/placeholder.jpg', 1, NOW()),
('Yoga Mat', 'Non-slip yoga mat with carrying strap.', 29.99, 4, 2, 'assets/images/placeholder.jpg', 0, NOW()),
('Building Blocks Set', 'Creative building blocks set with 500 pieces.', 45.99, 5, 1, 'assets/images/placeholder.jpg', 1, NOW()),
('Smart Watch', 'Fitness tracker and smartwatch with heart rate monitoring.', 149.99, 1, 2, 'assets/images/placeholder.jpg', 1, NOW());
