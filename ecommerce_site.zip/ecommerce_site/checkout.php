<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error) {
        echo "<pre>";
        print_r($error);
        echo "</pre>";
    }
});

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    header('Location: login.php');
    exit;
}

$cart = getCartItems($conn);
if (empty($cart['items'])) {
    header('Location: cart.php');
    exit;
}

$error = '';
$orderId = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip = $_POST['zip'] ?? '';

    if (empty($address) || empty($city) || empty($state) || empty($zip)) {
        $error = 'Please fill in all required fields.';
    } else {
        $result = createOrder(
            $conn,
            $_SESSION['user_id'],
            $cart['items'],
            $cart['total'] + 10.00 + ($cart['total'] * 0.08),
            $address,
            $city,
            $state,
            $zip
        );

        if ($result['success']) {
            $_SESSION['cart'] = [];
            header('Location: order-confirmation.php?id=' . $result['order_id']);
            exit;
        } else {
            $error = $result['message'];
        }
    }
}

include 'includes/header.php';
?>

<main class="container py-4">
    <h1 class="mb-4">Checkout</h1>

    <?php if ($error): ?>
        <div class="alert alert-danger" role="alert">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header"><h5 class="mb-0">Shipping Information</h5></div>
                <div class="card-body">
                    <form method="POST" action="checkout.php" class="needs-validation" novalidate>
                        <div class="mb-3">
                            <label for="address" class="form-label">Street Address *</label>
                            <input type="text" class="form-control" id="address" name="address" required>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="city" class="form-label">City *</label>
                                <input type="text" class="form-control" id="city" name="city" required>
                            </div>
                            <div class="col-md-3">
                                <label for="state" class="form-label">State *</label>
                                <input type="text" class="form-control" id="state" name="state" required>
                            </div>
                            <div class="col-md-3">
                                <label for="zip" class="form-label">ZIP Code *</label>
                                <input type="text" class="form-control" id="zip" name="zip" required>
                            </div>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header"><h5 class="mb-0">Payment Information</h5></div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="card_number" class="form-label">Card Number *</label>
                                    <input type="text" class="form-control" id="card_number" placeholder="1234 5678 9012 3456" required>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="expiration" class="form-label">Expiration Date *</label>
                                        <input type="text" class="form-control" id="expiration" placeholder="MM/YY" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="cvv" class="form-label">CVV *</label>
                                        <input type="text" class="form-control" id="cvv" placeholder="123" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="card_name" class="form-label">Name on Card *</label>
                                    <input type="text" class="form-control" id="card_name" placeholder="John Doe" required>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary btn-lg">Place Order</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card cart-summary mb-4">
                <div class="card-header"><h5 class="mb-0">Order Summary</h5></div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6 class="mb-2">Items (<?= count($cart['items']) ?>)</h6>
                        <?php foreach ($cart['items'] as $item): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span><?= htmlspecialchars($item['title']) ?> × <?= $item['quantity'] ?></span>
                                <span><?= formatCurrency($item['subtotal']) ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Subtotal:</span>
                        <span><?= formatCurrency($cart['total']) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Shipping:</span>
                        <span><?= formatCurrency(10.00) ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Tax (8%):</span>
                        <span><?= formatCurrency($cart['total'] * 0.08) ?></span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between mb-0">
                        <strong>Total:</strong>
                        <strong><?= formatCurrency($cart['total'] + 10.00 + ($cart['total'] * 0.08)) ?></strong>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h6 class="mb-3">Need Help?</h6>
                    <p class="small mb-0">
                        If you have questions about your order, contact support at 
                        <a href="mailto:support@marketplace.com">support@marketplace.com</a> or call (123) 456-7890.
                    </p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>

