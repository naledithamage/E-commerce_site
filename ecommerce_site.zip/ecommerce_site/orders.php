<?php
session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    $_SESSION['redirect_after_login'] = 'orders.php';
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];
$conn = getDBConnection();

$stmt = mysqli_prepare($conn, "
    SELECT o.id, o.total_amount, o.status, o.created_at
    FROM orders o
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
");
mysqli_stmt_bind_param($stmt, "i", $userId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$orders = mysqli_fetch_all($result, MYSQLI_ASSOC);

include 'includes/header.php';
?>

<main class="container py-4">
    <h1 class="mb-4">My Orders</h1>

    <?php if (empty($orders)): ?>
        <div class="alert alert-info">You haven't placed any orders yet.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>#<?php echo $order['id']; ?></td>
                            <td><?php echo formatCurrency($order['total_amount']); ?></td>
                            <td><?php echo ucfirst($order['status']); ?></td>
                            <td><?php echo date("F j, Y", strtotime($order['created_at'])); ?></td>
                            <td><a href="order-confirmation.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-primary">View</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
