<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: /login.php");
    exit;
}

$result = $conn->query("SELECT COUNT(*) AS total FROM products");
$row = $result->fetch_assoc();
$totalProducts = $row['total'];

$result = $conn->query("SELECT COUNT(*) AS total FROM orders");
$row = $result->fetch_assoc();
$totalOrders = $row['total'];

$result = $conn->query("SELECT COUNT(*) AS total FROM users");
$row = $result->fetch_assoc();
$totalUsers = $row['total'];

$result = $conn->query("SELECT SUM(total_amount) AS revenue FROM orders");
$row = $result->fetch_assoc();
$totalRevenue = $row['revenue'];
?>

<main class="container py-4">
    <h1 class="mb-4">Admin Dashboard</h1>

    <div class="row g-4">
        <div class="col-md-3">
            <div class="card text-white bg-primary shadow">
                <div class="card-body">
                    <h5>Total Products</h5>
                    <p class="display-6"><?php echo $totalProducts; ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-success shadow">
                <div class="card-body">
                    <h5>Total Orders</h5>
                    <p class="display-6"><?php echo $totalOrders; ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-info shadow">
                <div class="card-body">
                    <h5>Total Users</h5>
                    <p class="display-6"><?php echo $totalUsers; ?></p>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card text-white bg-dark shadow">
                <div class="card-body">
                    <h5>Total Revenue</h5>
                    <p class="display-6">R <?php echo number_format($totalRevenue ?? 0, 2); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-5 card">
        <div class="card-body">
            <h5 class="card-title">Sales Overview</h5>
            <canvas id="salesChart" height="120"></canvas>
        </div>
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('salesChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
            label: 'Sales (R)',
            data: [120, 250, 180, 220, 300, 260, 210],
            backgroundColor: 'rgba(13, 110, 253, 0.1)',
            borderColor: '#0d6efd',
            borderWidth: 2,
            fill: true,
            tension: 0.3
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>
