<?php
session_start();
require_once '../includes/db_connect.php';
require_once '../includes/functions.php';
require_once '../includes/header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: /login.php");
    exit;
}

// Handle role update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'], $_POST['role'])) {
    $userId = intval($_POST['user_id']);
    $newRole = $_POST['role'] === 'admin' ? 'admin' : 'user';

    $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->bind_param("si", $newRole, $userId);
    $stmt->execute();
    $stmt->close();
}

$result = $conn->query("SELECT id, name, email, role, created_at FROM users");
$users = $result->fetch_all(MYSQLI_ASSOC);
$result->free();
?>

<main class="container py-4">
    <h1 class="mb-4">Manage Users</h1>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Change Role</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= $user['id']; ?></td>
                    <td><?= htmlspecialchars($user['name']); ?></td>
                    <td><?= htmlspecialchars($user['email']); ?></td>
                    <td><?= $user['role']; ?></td>
                    <td><?= $user['created_at']; ?></td>
                    <td>
                        <?php if ($_SESSION['user_id'] != $user['id']): ?>
                        <form method="POST" style="display:inline-block;">
                            <input type="hidden" name="user_id" value="<?= $user['id']; ?>">
                            <select name="role" class="form-select form-select-sm d-inline w-auto">
                                <option value="user" <?= $user['role'] === 'user' ? 'selected' : ''; ?>>User</option>
                                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                            </select>
                            <button type="submit" class="btn btn-sm btn-primary">Update</button>
                        </form>
                        <?php else: ?>
                            <em>(You)</em>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php require_once '../includes/footer.php'; ?>
