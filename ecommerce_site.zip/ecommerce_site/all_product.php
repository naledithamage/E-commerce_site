<?php
session_start();
require_once 'includes/functions.php';

$conn = getDBConnection();


$category = $_GET['category'] ?? null;
$search = $_GET['search'] ?? null;


$products = getProducts($conn, $category, $search);
$categories = getCategories($conn);

include 'includes/header.php';
?>

<main class="container py-5">
    <h1 class="mb-4">Browse Products</h1>

    
    <form class="row mb-4" method="GET" action="all_products.php">
        <div class="col-md-4 mb-2">
            <select class="form-select" name="category">
                <option value="">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>" <?= ($cat['id'] == $category ? 'selected' : '') ?>>
                        <?= htmlspecialchars($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-6 mb-2">
            <input type="text" class="form-control" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search ?? '') ?>">
        </div>
        <div class="col-md-2 mb-2">
            <button class="btn btn-primary w-100" type="submit">Filter</button>
        </div>
    </form>

    <?php if (empty($products)): ?>
        <div class="alert alert-info">No products found.</div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php foreach ($products as $product): ?>
                <div class="col">
                    <div class="card h-100">
                        <img src="assets/images/<?= htmlspecialchars($product['image'] ?? 'placeholder.jpg') ?>" 
                             class="card-img-top" 
                             alt="<?= htmlspecialchars($product['title']) ?>"
                             style="height: 200px; object-fit: cover;"
                             onerror="this.src='assets/images/placeholder.jpg';">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product['title']) ?></h5>
                            <p class="text-muted small mb-1">Sold by <?= htmlspecialchars($product['seller_name']) ?></p>
                            <p class="text-primary fw-bold"><?= formatCurrency($product['price']) ?></p>
                        </div>
                        <div class="card-footer border-0 bg-white">
                            <a href="product.php?id=<?= urlencode($product['id']) ?>" class="btn btn-outline-primary btn-sm w-100">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>
