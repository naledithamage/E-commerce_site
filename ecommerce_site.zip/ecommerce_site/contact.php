<?php

session_start();
require_once 'includes/db_connect.php';
require_once 'includes/functions.php';


if (!isLoggedIn()) {
    
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header('Location: login.php');
    exit;
}


if (!isset($_GET['product']) || empty($_GET['product'])) {
    header('Location: index.php');
    exit;
}

$productId = $_GET['product'];
$product = getProductById($conn, $productId);


if (!$product) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = $_POST['message'] ?? '';
    
    if (empty($message)) {
        $error = 'Please enter a message.';
    } else {
        
        $success = 'Your message has been sent to the seller.';
    }
}


include 'includes/header.php';
?>

<main class="container py-4">
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="product.php?id=<?php echo $productId; ?>"><?php echo htmlspecialchars($product['title']); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">Contact Seller</li>
        </ol>
    </nav>
    
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0">Contact Seller</h5>
                </div>
                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($success): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo htmlspecialchars($success); ?>
                            <a href="product.php?id=<?php echo $productId; ?>" class="alert-link">Return to product</a>
                        </div>
                    <?php else: ?>
                    
                    <div class="mb-4">
                        <div class="d-flex align-items-center">
                            <img src="<?php echo !empty($product['image']) ? $product['image'] : 'assets/images/placeholder.jpg'; ?>" 
                                alt="<?php echo htmlspecialchars($product['title']); ?>" 
                                class="cart-item-img rounded me-3">
                            <div>
                                <h6 class="mb-1"><?php echo htmlspecialchars($product['title']); ?></h6>
                                <p class="mb-0 text-muted">Sold by <?php echo htmlspecialchars($product['seller_name']); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <form method="POST" action="contact-seller.php?product=<?php echo $productId; ?>">
                        <div class="mb-3">
                            <label for="message" class="form-label">Your Message</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">Send Message</button>
                            <a href="product.php?id=<?php echo $productId; ?>" class="btn btn-outline-secondary">Cancel</a>
                        </div>
                    </form>
                    
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php

include 'includes/footer.php';
?>