// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
    // Initialize quantity controls for cart
    initQuantityControls()
  
    // Initialize product image preview on sell form
    initImagePreview()
  
    // Initialize form validation
    initFormValidation()
  })
  
  // Handle quantity control buttons in cart
  function initQuantityControls() {
    const quantityControls = document.querySelectorAll(".quantity-control")
  
    if (quantityControls) {
      quantityControls.forEach((control) => {
        const decreaseBtn = control.querySelector(".decrease-qty")
        const increaseBtn = control.querySelector(".increase-qty")
        const quantityInput = control.querySelector(".quantity-input")
        const updateForm = control.closest("form")
  
        if (decreaseBtn && increaseBtn && quantityInput) {
          decreaseBtn.addEventListener("click", (e) => {
            e.preventDefault()
            const currentValue = Number.parseInt(quantityInput.value)
            if (currentValue > 1) {
              quantityInput.value = currentValue - 1
              if (updateForm) {
                updateForm.submit()
              }
            }
          })
  
          increaseBtn.addEventListener("click", (e) => {
            e.preventDefault()
            const currentValue = Number.parseInt(quantityInput.value)
            quantityInput.value = currentValue + 1
            if (updateForm) {
              updateForm.submit()
            }
          })
        }
      })
    }
  }
  
  // Show image preview when uploading product image
  function initImagePreview() {
    const imageInput = document.getElementById("product-image")
    const imagePreview = document.getElementById("image-preview")
  
    if (imageInput && imagePreview) {
      imageInput.addEventListener("change", function () {
        if (this.files && this.files[0]) {
          const reader = new FileReader()
  
          reader.onload = (e) => {
            imagePreview.src = e.target.result
            imagePreview.style.display = "block"
          }
  
          reader.readAsDataURL(this.files[0])
        }
      })
    }
  }
  
  // Basic form validation
  function initFormValidation() {
    const forms = document.querySelectorAll(".needs-validation")
  
    if (forms) {
      Array.from(forms).forEach((form) => {
        form.addEventListener(
          "submit",
          (event) => {
            if (!form.checkValidity()) {
              event.preventDefault()
              event.stopPropagation()
            }
  
            form.classList.add("was-validated")
          },
          false,
        )
      })
    }
  }
  
  
  function confirmDelete(message) {
    return confirm(message || "Are you sure you want to delete this item?")
  }
  