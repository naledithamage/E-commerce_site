<?php
session_start();
require_once 'includes/functions.php';

$conn = getDBConnection();
$categories = getCategories($conn);
$featuredProducts = getFeaturedProducts($conn);

include 'includes/header.php';
?>

<main class="container-fluid px-0">
<!-- HERO BANNER -->
<section class="bg-light py-5" style="background: linear-gradient(to right, #e0f2ff, #fdf1ff);">
<div class="container d-flex flex-column flex-lg-row align-items-center justify-content-between">
<div class="text-center text-lg-start mb-4 mb-lg-0">
<h6 class="text-uppercase text-muted fw-semibold">Your Trusted Marketplace</h6>
<h1 class="display-5 fw-bold">Welcome to <span class="text-primary">Cartari</span></h1>
<p class="text-muted fs-5">Buy and sell everyday goods — fast, simple, secure.</p>
<div class="d-flex gap-3 justify-content-center justify-content-lg-start">
<a href="sell/sell.php" class="btn btn-dark btn-lg">Start Selling</a>
<a href="all_product.php" class="btn btn-outline-secondary btn-lg">Browse Products</a>
</div>
</div>
<div>
<img src="assets/images/cartari-hero.png" alt="Marketplace Banner" class="img-fluid" style="max-height: 300px;" onerror="this.style.display='none';">
</div>
</div>
</section>

<!-- WHY CARTARI -->
<section class="py-5" style="background: linear-gradient(to right, #d9f2e6, #ffffff);">
<div class="container d-flex flex-column flex-lg-row align-items-center">
<div class="col-lg-6 mb-4 mb-lg-0">
<h2 class="fw-bold">Why Cartari?</h2>
<p class="text-muted">
Whether you're cleaning out your closet or looking for a great deal, Cartari helps you connect with people nearby to buy and sell everyday items easily and securely.
No hidden fees, no hassle — just a simple, trusted way to trade.
</p>
</div>
<div class="col-lg-6 text-center">
<img src="assets/images/why-cartari.png" alt="Cartari benefits" class="img-fluid" style="max-height: 250px;" onerror="this.style.display='none';">
</div>
</div>
</section>

<!-- SHOP BY CATEGORY -->
<section class="py-5 bg-light">
  <div class="container text-center">
    <h2 class="fw-bold mb-4">Shop by Category</h2>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-4">
      <?php
      $imageMap = [
        'Clothing' => 'Plain-Sweat-Black.png',
        'Electronics' => 'mobilephone.jpg',
        'Home & Garden' => 'plants.jpg',
        'Sports & Outdoors' => 'tennisracket.jpg',
        'Toys & Games' => 'spidermanfigure.webp'
      ];
      ?>
      <?php foreach (array_slice($categories, 0, 6) as $cat): ?>
        <?php
        $categoryName = $cat['name'];
        $imageFile = $imageMap[$categoryName] ?? 'default.jpg';
        ?>
        <div class="col">
          <a href="all_product.php?category=<?php echo htmlspecialchars($cat['id']); ?>" class="text-decoration-none text-dark">
            <div class="card h-100 shadow-sm border-0 rounded-4">
              <img src="assets/images/<?php echo $imageFile; ?>"
                   class="card-img-top rounded-top-4"
                   alt="<?php echo htmlspecialchars($categoryName); ?>"
                   onerror="this.onerror=null;this.src='assets/images/default.jpg';">
              <div class="card-body">
                <h5 class="card-title fw-semibold"><?php echo htmlspecialchars($categoryName); ?></h5>
                <p class="card-text text-muted small">
                  Browse the best in <?php echo htmlspecialchars($categoryName); ?> from trusted sellers.
                </p>
              </div>
            </div>
          </a>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="mt-4">
      <a href="all_product.php" class="btn btn-outline-primary btn-lg">View All Products</a>
    </div>
  </div>
</section>


<!-- FEATURED PRODUCTS -->
<section class="py-5">
<div class="container text-center">
<h2 class="fw-bold mb-4">Featured Products</h2>
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 g-4">
<?php
$customFeatured = [
  ['name' => 'Wireless Headphones', 'image' => 'wireless_headphones.jpeg', 'price' => 799.99, 'id' => 1],
  ['name' => 'Denim Jacket', 'image' => 'denim_jacket.webp', 'price' => 549.99, 'id' => 2],
  ['name' => 'Indoor Plant Set', 'image' => 'indoor_plant_set.jpg', 'price' => 299.99, 'id' => 3],
  ['name' => 'Building Block Set', 'image' => 'buildingblocksset.jpg', 'price' => 149.99, 'id' => 4],
  ['name' => 'Smart Watch', 'image' => 'smart_watch.jpeg', 'price' => 999.99, 'id' => 5],
];
?>

<?php foreach ($customFeatured as $product): ?>
<div class="col">
  <div class="card h-100 border-0 shadow-sm rounded-4">
    <img src="assets/images/<?php echo htmlspecialchars($product['image']); ?>"
         class="card-img-top rounded-top-4"
         alt="<?php echo htmlspecialchars($product['name']); ?>"
         onerror="this.onerror=null;this.src='assets/images/default.jpg';">
    <div class="card-body">
      <h5 class="card-title fw-semibold"><?php echo htmlspecialchars($product['name']); ?></h5>
      <p class="price text-muted">R<?php echo number_format($product['price'], 2); ?></p>
      <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-outline-primary">View Product</a>
    </div>
  </div>
</div>
<?php endforeach; ?>
</div>
</div>
</section>

</main>

<?php include 'includes/footer.php'; ?>