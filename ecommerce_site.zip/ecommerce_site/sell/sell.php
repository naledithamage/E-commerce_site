<?php
session_start();
require_once '../includes/db_connect.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: /login.php");
    exit;
}

$error = '';
$success = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (empty($_POST['title']) || empty($_POST['description']) || empty($_POST['price'])) {
            throw new Exception("All fields are required.");
        }

        $title = htmlspecialchars(trim($_POST['title']));
        $description = htmlspecialchars(trim($_POST['description']));
        $price = (float)$_POST['price'];
        $seller_id = $_SESSION['user_id'];
        $category_id = 1; 
        $is_featured = 0;

        
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            throw new Exception("Please upload a valid image.");
        }

        $image = $_FILES['image'];
        $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        $maxSize = 5 * 1024 * 1024;

        if (!in_array($image['type'], $allowedTypes)) {
            throw new Exception("Only JPG, PNG, or WEBP files are allowed.");
        }

        if ($image['size'] > $maxSize) {
            throw new Exception("Image is too large. Max 5MB.");
        }

        
        $imageDir = '../assets/images/';
        if (!is_dir($imageDir)) {
            mkdir($imageDir, 0755, true);
        }

        $ext = pathinfo($image['name'], PATHINFO_EXTENSION);
        $imageName = 'product_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $targetPath = $imageDir . $imageName;

        if (!move_uploaded_file($image['tmp_name'], $targetPath)) {
            throw new Exception("Image upload failed.");
        }

        
        $stmt = $conn->prepare("INSERT INTO products (seller_id, title, description, price, image, category_id, is_featured, created_at, status)
                                VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), 'active')");
        $stmt->execute([$seller_id, $title, $description, $price, $imageName, $category_id, $is_featured]);

        $success = "Product listed successfully!";
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sell a Product - MarketPlace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/styles.css">
</head>
<body>

<?php include '../includes/header.php'; ?>

<main class="container py-5">
    <div class="mx-auto" style="max-width: 600px;">
        <h1 class="mb-4">List a Product for Sale</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <form action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Product Title*</label>
                <input type="text" class="form-control" id="title" name="title" required 
                       value="<?= isset($_POST['title']) ? htmlspecialchars($_POST['title']) : '' ?>">
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description*</label>
                <textarea class="form-control" id="description" name="description" rows="4" required><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
            </div>

            <div class="mb-3">
                <label for="price" class="form-label">Price ($)*</label>
                <input type="number" class="form-control" id="price" name="price" min="0" step="0.01" required 
                       value="<?= isset($_POST['price']) ? htmlspecialchars($_POST['price']) : '' ?>">
            </div>

            <div class="mb-3">
                <label for="image" class="form-label">Product Image*</label>
                <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                <div class="form-text">Max 5MB (JPG, PNG, WEBP)</div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2">Submit Listing</button>
        </form>
    </div>
</main>

<?php include '../includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
