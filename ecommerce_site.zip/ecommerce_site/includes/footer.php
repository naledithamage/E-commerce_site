<footer class="bg-light mt-5 py-4 border-top">
    <div class="container">
        <div class="row">
            
            <div class="col-md-4 mb-4 mb-md-0">
                <h5 class="text-primary fw-bold">Cartari</h5>
                <p class="text-muted">Your trusted marketplace for buying and selling everyday goods.</p>
            </div>

            
            <div class="col-md-2 mb-4 mb-md-0">
                <h6 class="fw-semibold">Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-decoration-none text-muted">Home</a></li>
                    <li><a href="sell.php" class="text-decoration-none text-muted">Sell</a></li>
                    <li><a href="cart.php" class="text-decoration-none text-muted">Cart</a></li>
                </ul>
            </div>

            
            <div class="col-md-2 mb-4 mb-md-0">
                <h6 class="fw-semibold">Categories</h6>
                <ul class="list-unstyled">
                    <?php
                    $topCategories = array_slice(getCategories($conn), 0, 4);
                    foreach ($topCategories as $category) {
                        echo '<li><a href="index.php?category=' . $category['id'] . '" class="text-decoration-none text-muted">' . htmlspecialchars($category['name']) . '</a></li>';
                    }
                    ?>
                </ul>
            </div>

            
            <div class="col-md-4">
                <h6 class="fw-semibold">Contact Us</h6>
                <ul class="list-unstyled text-muted">
                    <li>Email: support@cartari.com</li>
                    <li>Phone: (123) 456-7890</li>
                    <li>Address: 123 Cartari Lane, Commerce City, Country</li>
                </ul>
            </div>
        </div>

        <hr>

        
        <div class="d-flex justify-content-between align-items-center flex-column flex-md-row">
            <p class="text-muted mb-2 mb-md-0">&copy; <?php echo date('Y'); ?> Cartari. All rights reserved.</p>
            <div class="social-links">
                <a href="#" class="text-muted me-2"><i class="fab fa-facebook"></i></a>
                <a href="#" class="text-muted me-2"><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-muted me-2"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
</footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


<script src="assets/js/script.js"></script>
</body>
</html>
