<?php

$host = 'localhost';
$dbname = 'ecommerce';
$username = 'root';
$password = '20040121Nt#';

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
