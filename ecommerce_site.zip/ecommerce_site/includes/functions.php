<?php

function getDBConnection() {
    static $conn = null;
    if ($conn === null) {
        $host = 'localhost';
        $username = 'root';
        $password = '20040121Nt#';
        $database = 'ecommerce';

        $conn = mysqli_connect($host, $username, $password, $database);
        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }
    }
    return $conn;
}

function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443 ? "https://" : "http://";
    return $protocol . $_SERVER['HTTP_HOST'];
}

function formatCurrency($amount) {
    return 'R' . number_format((float)$amount, 2);
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) &&
           $_SESSION['user_ip'] === $_SERVER['REMOTE_ADDR'] &&
           $_SESSION['user_agent'] === $_SERVER['HTTP_USER_AGENT'] &&
           (time() - $_SESSION['login_time']) < 3600;
}

function loginUser($conn, $email, $password) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = htmlspecialchars($user['name']);
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'];
        $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        $_SESSION['login_time'] = time();
        $_SESSION['role'] = $user['role'];

        return ['success' => true, 'message' => 'Login successful'];
    }

    return ['success' => false, 'message' => 'Invalid credentials'];
}

function getFeaturedProducts($conn, $limit = 6) {
    $stmt = mysqli_prepare($conn, "
        SELECT p.*, u.name as seller_name 
        FROM products p 
        JOIN users u ON p.seller_id = u.id 
        WHERE p.is_featured = 1 AND p.status = 'active'
        ORDER BY p.created_at DESC 
        LIMIT ?
    ");
    mysqli_stmt_bind_param($stmt, "i", $limit);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function getProducts($conn, $category = null, $search = null) {
    $sql = "
        SELECT p.*, u.name as seller_name 
        FROM products p 
        JOIN users u ON p.seller_id = u.id 
        WHERE p.status = 'active'
    ";
    $params = [];
    $types = "";

    if ($category) {
        $sql .= " AND p.category_id = ?";
        $params[] = $category;
        $types .= "i";
    }

    if ($search) {
        $sql .= " AND (p.title LIKE ? OR p.description LIKE ?)";
        $searchTerm = '%' . $search . '%';
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $types .= "ss";
    }

    $sql .= " ORDER BY p.created_at DESC";
    $stmt = mysqli_prepare($conn, $sql);

    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function getProductById($conn, $id) {
    $stmt = mysqli_prepare($conn, "
        SELECT p.*, u.name AS seller_name, c.name AS category_name
        FROM products p
        JOIN users u ON p.seller_id = u.id
        JOIN categories c ON p.category_id = c.id
        WHERE p.id = ? AND p.status = 'active'
    ");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

function getCategories($conn) {
    $result = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

function addToCart($productId, $quantity = 1) {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    $_SESSION['cart'][$productId] = ($_SESSION['cart'][$productId] ?? 0) + $quantity;
}

function updateCartItemQuantity($productId, $quantity) {
    if (isset($_SESSION['cart'][$productId])) {
        if ($quantity > 0) {
            $_SESSION['cart'][$productId] = $quantity;
        } else {
            unset($_SESSION['cart'][$productId]);
        }
    }
}

function removeFromCart($productId) {
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]);
    }
}

function getCartCount() {
    return isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
}

function getCartItems($conn) {
    if (empty($_SESSION['cart'])) {
        return ['items' => [], 'total' => 0];
    }

    $productIds = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($productIds), '?'));
    $types = str_repeat("i", count($productIds));

    $stmt = mysqli_prepare($conn, "
        SELECT p.*, u.name AS seller_name
        FROM products p
        JOIN users u ON p.seller_id = u.id
        WHERE p.id IN ($placeholders)
    ");
    mysqli_stmt_bind_param($stmt, $types, ...$productIds);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $items = mysqli_fetch_all($result, MYSQLI_ASSOC);

    $total = 0;
    foreach ($items as &$item) {
        $item['quantity'] = $_SESSION['cart'][$item['id']];
        $item['subtotal'] = $item['quantity'] * $item['price'];
        $total += $item['subtotal'];
    }

    return ['items' => $items, 'total' => $total];
}

function createOrder($conn, $userId, $items, $total, $address, $city, $state, $zip) {
    mysqli_begin_transaction($conn);
    try {
        $stmt = mysqli_prepare($conn, "
            INSERT INTO orders (user_id, total_amount, shipping_address, shipping_city, shipping_state, shipping_zip, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
        ");
        mysqli_stmt_bind_param($stmt, "idssss", $userId, $total, $address, $city, $state, $zip);
        mysqli_stmt_execute($stmt);
        $orderId = mysqli_insert_id($conn);

        $stmtItem = mysqli_prepare($conn, "
            INSERT INTO order_items (order_id, product_id, quantity, price)
            VALUES (?, ?, ?, ?)
        ");
        foreach ($items as $item) {
            mysqli_stmt_bind_param($stmtItem, "iiid", $orderId, $item['id'], $item['quantity'], $item['price']);
            mysqli_stmt_execute($stmtItem);
        }

        mysqli_commit($conn);
        return ['success' => true, 'order_id' => $orderId];
    } catch (Exception $e) {
        mysqli_rollback($conn);
        error_log("Order creation failed: " . $e->getMessage());
        return ['success' => false, 'message' => 'Order could not be placed.'];
    }
}

function registerUser($conn, $name, $email, $password) {
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $createdAt = date('Y-m-d H:i:s'); // current timestamp

    $stmt = mysqli_prepare($conn, "INSERT INTO users (name, email, password, role, created_at) VALUES (?, ?, ?, 'user', ?)");
    if (!$stmt) {
        return ['success' => false, 'message' => 'Prepare failed: ' . mysqli_error($conn)];
    }

    mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hashedPassword, $createdAt);
    $success = mysqli_stmt_execute($stmt);

    if ($success) {
        return ['success' => true, 'message' => 'Registration successful'];
    } else {
        return ['success' => false, 'message' => 'Registration failed: ' . mysqli_stmt_error($stmt)];
    }
}


